export const MAX_IMAGES = 5;
