export const TOOL_CALL_JSON_CODE_BLOCK_REGEX = /```tool_code\s*([\s\S]*?)\s*```/;
